/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
/*!**********************************************************************!*\
  !*** ../demo1/src/js/pages/crud/forms/editors/bootstrap-markdown.js ***!
  \**********************************************************************/

// Class definition

var KTBootstrapMarkdown = function () {    
    // Private functions
    var demos = function () {
        
    }

    return {
        // public functions
        init: function() {
            demos(); 
        }
    };
}();

// Initialization
jQuery(document).ready(function() {
    KTBootstrapMarkdown.init();
});
/******/ })()
;
//# sourceMappingURL=bootstrap-markdown.js.map